#!/usr/bin/env python3
#! -*- coding: utf-8 -*-
from termcolor import colored

print("")
print("")
print("")
print("")
print("")
print("")
print("")
print("")
print("")
print("")
print("")
print("")
print("")
print("")
print("")
print("")
print("")
print("")
print("")
print("")
print("")
print("")
print("")
print("")
print("")
print(colored("                          ....            ....", 'red', 'on_grey'))
print(colored("                      .......              .......", 'red', 'on_grey'))
print(colored("                     ......                 .......", 'red', 'on_grey'))
print(colored("                     .                             .", 'red', 'on_grey'))




















